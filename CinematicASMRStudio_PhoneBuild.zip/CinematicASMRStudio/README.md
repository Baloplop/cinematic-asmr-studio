# Cinematic ASMR Studio — Milestone 1

A native Kotlin + Jetpack Compose Android **foundation** with a 13-step guided workflow, editable approval screens, mock scene prompts, numbered scene navigation, purple clipboard confirmation, and locally saved projects.

## Build
1. Open this folder in **Android Studio** (JDK 17 and Android SDK 35 installed).
2. Let Gradle sync and download dependencies.
3. Run the `app` configuration on an emulator or Android device.
4. To build a debug APK, run `./gradlew assembleDebug` once a Gradle wrapper is generated, or use Android Studio **Build > Build APK(s)**.

The project intentionally does not include generated Gradle wrapper files; Android Studio may prompt to configure Gradle. Use a compatible Gradle 8.9 distribution for Android Gradle Plugin 8.7.3.

## Implemented
- Home and locally saved projects (SharedPreferences JSON for the MVP)
- 13-step wizard and direct selection advancement
- Story, continuity, storyboard and final approval stages
- Style lock and platform selection
- Scene number buttons, paired mock prompts, four ASMR layer labels
- Independent dark-to-purple copy controls

## Known limitations / next milestones
- **Not compiled or tested in this environment.** Dependency resolution and Android build must be verified in Android Studio.
- Mock content only; no AI API, image, sound or video rendering.
- Food gallery is text-only; no authenticated food photos or authentic dish database.
- No full structured storyboard timeline planner or accurate per-scene timecodes yet.
- Project persistence uses SharedPreferences rather than Room; no migration or backup.
- Approval invalidation currently occurs on approval edits, not every upstream choice change; strengthen in milestone 2.
- Final package is a mock editable review, not a full production export.
- Full-body/hands-only mode choice is represented in a text field, not a separate production mode selector yet.
- Missing instrumented and unit tests, advanced accessibility checks, and production hardening.

This is an editable working-code starting point, **not a finished production APK**.
