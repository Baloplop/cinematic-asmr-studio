package com.cinematicasmr.studio

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

private val Purple = Color(0xFF8C52FF)
private val Bg = Color(0xFF13101C)
private val Surface = Color(0xFF262033)
private val steps = listOf(
    "Production Type", "Story Concept", "Cuisine or Subject Gallery", "Story Approval",
    "Atmosphere", "Duration & Aspect Ratio", "Camera & Pacing", "Visual Style Lock",
    "Character & Continuity Approval", "Storyboard Approval", "Animation Platform",
    "Scene Prompt Studio", "Final Package Approval"
)
private val options = mapOf(
    1 to listOf("Food & Cooking ASMR", "Arts & Crafts", "DIY & Handmade", "Relaxing Object ASMR", "Satisfying Transformations", "Cozy Everyday Rituals", "Nature & Outdoors", "Cinematic Emotional Story", "Custom"),
    2 to listOf("Peaceful Morning", "Cozy Rainy Day", "Quiet Evening", "Traditional Homemade Comfort", "Seasonal Celebration", "Nostalgic Memory", "Relaxing Weekend", "Working Abroad", "Love & Life Lesson", "Custom"),
    3 to listOf("Japanese", "Filipino", "Korean", "Chinese", "Indian", "European", "American", "Mexican", "International", "Custom"),
    5 to listOf("Warm & Cozy", "Dreamy & Peaceful", "Calm & Minimalist", "Rustic & Traditional", "Soft & Romantic", "Bright & Cheerful", "Moody & Cinematic", "Custom"),
    6 to listOf("30 sec · 9:16", "60 sec · 9:16", "90 sec · 9:16", "2 min · 9:16", "3 min · 9:16", "5 min · 9:16", "90 sec · 16:9", "Custom"),
    7 to listOf("Slow & Soothing Macro", "Gentle Cinematic Storytelling", "Satisfying Rhythmic Preparation", "Detailed Tactile Close-Ups", "Balanced Preparation & Reveal", "Meditative Long Takes"),
    11 to listOf("Meta AI", "Google Flow / Veo", "Both Meta AI & Google Flow", "Runway", "Kling AI", "Pika", "Universal Image-to-Video", "Custom")
)

private data class Project(
    val id: String = UUID.randomUUID().toString(),
    var name: String = "Untitled Production",
    var step: Int = 1,
    val choices: MutableMap<Int,String> = mutableMapOf(),
    val approvals: MutableSet<Int> = mutableSetOf(),
    var scene: Int = 1,
    var story: String = "",
    var character: String = "",
    var storyboard: String = ""
) {
    fun json(): JSONObject = JSONObject().apply {
        put("id",id);put("name",name);put("step",step);put("scene",scene)
        put("choices",JSONObject().apply { choices.forEach { (k,v)->put(k.toString(),v) } })
        put("approvals",JSONArray().apply { approvals.forEach { put(it) } })
        put("story",story);put("character",character);put("storyboard",storyboard)
    }
}
private fun decode(o:JSONObject):Project {
    val p=Project(o.optString("id",UUID.randomUUID().toString()),o.optString("name","Untitled Production"),o.optInt("step",1).coerceIn(1,13))
    p.scene=o.optInt("scene",1).coerceAtLeast(1)
    val c=o.optJSONObject("choices") ?: JSONObject()
    c.keys().forEach { key -> key.toIntOrNull()?.let { p.choices[it]=c.optString(key) } }
    val a=o.optJSONArray("approvals") ?: JSONArray()
    for(i in 0 until a.length()) p.approvals.add(a.optInt(i))
    p.story=o.optString("story");p.character=o.optString("character");p.storyboard=o.optString("storyboard")
    return p
}
private class Store(ctx:Context) {
    private val pref=ctx.getSharedPreferences("studio_projects",Context.MODE_PRIVATE)
    fun load():List<Project> = try {
        val a=JSONArray(pref.getString("projects","[]"));(0 until a.length()).map { decode(a.getJSONObject(it)) }
    } catch (_:Exception) { emptyList() }
    fun save(list:List<Project>) { pref.edit().putString("projects",JSONArray().apply { list.forEach { put(it.json()) } }.toString()).apply() }
}
class MainActivity:ComponentActivity() {
    override fun onCreate(savedInstanceState:Bundle?) { super.onCreate(savedInstanceState);setContent { StudioApp() } }
}
@Composable private fun StudioApp() {
    val context=LocalContext.current
    val store=remember { Store(context) }
    val projects=remember { mutableStateListOf<Project>().apply { addAll(store.load()) } }
    var selectedId by remember { mutableStateOf<String?>(null) }
    var refresh by remember { mutableIntStateOf(0) }
    val project=projects.firstOrNull { it.id==selectedId }
    fun save() { refresh++;store.save(projects.toList()) }
    MaterialTheme(colorScheme=darkColorScheme(primary=Purple,background=Bg,surface=Surface,onBackground=Color.White,onSurface=Color.White)) {
        Column(Modifier.fillMaxSize().background(Bg).padding(16.dp)) {
            Text("CINEMATIC ASMR STUDIO",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold,color=Color.White)
            Text("Ultra-smooth 2D cinematic production",color=Color.LightGray)
            Spacer(Modifier.height(18.dp))
            if(project==null) {
                Button(onClick={ val p=Project(name="Production ${projects.size+1}");projects.add(p);selectedId=p.id;save() },modifier=Modifier.fillMaxWidth()) { Text("+ NEW PROJECT") }
                Spacer(Modifier.height(12.dp))
                Text("SAVED PROJECTS",fontWeight=FontWeight.Bold)
                LazyColumn { items(projects,key={it.id}) { p ->
                    Card(Modifier.fillMaxWidth().padding(vertical=5.dp).clickable { selectedId=p.id }) {
                        Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) { Text(p.name,fontWeight=FontWeight.Bold);Text("Step ${p.step} of 13",color=Color.LightGray) }
                            TextButton(onClick={projects.removeAll { it.id==p.id };save()}) { Text("Delete") }
                        }
                    }
                } }
            } else {
                key(project.id,refresh) { ProjectScreen(project,onSave={save()},onBack={selectedId=null}) }
            }
        }
    }
}
@Composable private fun ProjectScreen(p:Project,onSave:()->Unit,onBack:()->Unit) {
    var rename by remember(p.id) { mutableStateOf(p.name) }
    Row(verticalAlignment=Alignment.CenterVertically) {
        TextButton(onClick=onBack) { Text("← Projects") }
        Spacer(Modifier.weight(1f));Text("${p.step}/13",color=Color.LightGray)
    }
    OutlinedTextField(value=rename,onValueChange={rename=it;p.name=it;onSave()},label={Text("Project name")},modifier=Modifier.fillMaxWidth(),singleLine=true)
    Spacer(Modifier.height(12.dp))
    LinearProgressIndicator(progress={p.step/13f},modifier=Modifier.fillMaxWidth())
    Spacer(Modifier.height(12.dp))
    Text("STEP ${p.step.toString().padStart(2,'0')} — ${steps[p.step-1]}",fontWeight=FontWeight.Bold)
    Spacer(Modifier.height(8.dp))
    Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
        when(p.step) {
            1,2,3,5,6,7,11 -> {
                if(p.step==3 && p.choices[1] !in listOf("Food & Cooking ASMR",null)) Text("Select a subject category (mock gallery).",color=Color.LightGray)
                Text("Tap an option to select and advance. ⭐ marks one recommendation.",color=Color.LightGray)
                options[p.step].orEmpty().forEachIndexed { i,s ->
                    Button(onClick={p.choices[p.step]=s;p.step++;onSave()},modifier=Modifier.fillMaxWidth().padding(vertical=3.dp),shape=RoundedCornerShape(if(p.step==3) 50.dp else 14.dp),colors=ButtonDefaults.buttonColors(containerColor=Surface)) {
                        Text("${i+1}. ${if(i==0) "⭐ " else ""}$s${if(p.step==3) "   SUBMIT" else ""}")
                    }
                }
            }
            4,9,10,13 -> ApprovalScreen(p,onSave)
            8 -> {
                Text("LOCKED: Ultra-smooth Ghibli-inspired 2D animation. Soft watercolor textures, stable outlines, cinematic lighting, graceful motion and consistent character identity.")
                Button(onClick={p.step=9;onSave()}) { Text("Continue with locked style") }
            }
            12 -> SceneStudio(p,onSave)
        }
    }
    Spacer(Modifier.height(8.dp))
    if(p.step>1) TextButton(onClick={p.step--;onSave()}) { Text("← Previous step") }
}
@Composable private fun ApprovalScreen(p:Project,onSave:()->Unit) {
    val step=p.step
    val initial=when(step) {
        4 -> if(p.story.isNotBlank()) p.story else "Title: ${p.choices[2] ?: "Cozy Story"}\nHook: A quiet moment changes everything.\nBeginning: Set the scene.\nMiddle: Show a meaningful action.\nEnding: A gentle life lesson."
        9 -> if(p.character.isNotBlank()) p.character else "MODE: Hands-only / full-body (edit as needed)\nCHAR-01 / HAND-01: Consistent identity\nENV-01: Stable environment\nPROP-01: Stable props\nFOOD-01: Logical food progression\nCAM-01: Smooth framing\nAUD-01: Four ASMR layers"
        10 -> if(p.storyboard.isNotBlank()) p.storyboard else (1..9).joinToString("\n") { "Scene $it: ${(it-1)*10}–${it*10}s — cinematic action, continuity and sound" }
        else -> "FINAL PACKAGE (mock)\nTitle: ${p.choices[2] ?: "Cinematic Story"}\nCaption: A beautiful cinematic ASMR moment.\nHashtags: #ASMR #Animation #Cinematic\nThumbnail: Hand-painted cinematic composition.\nQC: Review scene prompts and continuity."
    }
    var draft by remember(p.id,step) { mutableStateOf(initial) }
    Text("Review and edit before approval. Changes to an earlier stage invalidate downstream approvals.",color=Color.LightGray)
    OutlinedTextField(value=draft,onValueChange={draft=it},modifier=Modifier.fillMaxWidth().heightIn(min=210.dp),label={Text("Review content")})
    Spacer(Modifier.height(12.dp))
    Button(onClick={
        when(step) { 4->p.story=draft;9->p.character=draft;10->p.storyboard=draft }
        p.approvals.removeAll { it>step };p.approvals.add(step)
        if(step<13) p.step++
        onSave()
    },modifier=Modifier.fillMaxWidth()) { Text(if(step==13) "APPROVE FINAL PACKAGE ✓" else "APPROVE & CONTINUE ✓") }
    if(step==13 && 13 in p.approvals) Text("Final package approved ✓",color=Purple)
}
@Composable private fun SceneStudio(p:Project,onSave:()->Unit) {
    val ctx=LocalContext.current
    val sceneCount=when { p.choices[6]?.startsWith("30") == true ->3;p.choices[6]?.startsWith("60")==true->6;p.choices[6]?.startsWith("2 min")==true->12;p.choices[6]?.startsWith("3 min")==true->18;p.choices[6]?.startsWith("5 min")==true->30;else->9 }
    Text("Tap any scene number. No NEXT SCENE button.",color=Color.LightGray)
    (1..sceneCount).chunked(6).forEach { chunk ->
        Row(horizontalArrangement=Arrangement.spacedBy(5.dp),modifier=Modifier.fillMaxWidth()) {
            chunk.forEach { n ->
                Button(onClick={p.scene=n;onSave()},modifier=Modifier.weight(1f),contentPadding=PaddingValues(0.dp),colors=ButtonDefaults.buttonColors(containerColor=if(p.scene==n) Purple else Surface)) { Text("$n") }
            }
        }
    }
    val imagePrompt="SCENE ${p.scene} — IMAGE PROMPT\nUltra-smooth Ghibli-inspired 2D hand-painted animation. ${p.choices[5] ?: "Cozy"} atmosphere. Maintain CHAR-01/HAND-01, ENV-01, PROP-01, FOOD-01, CAM-01. Stable colors, soft watercolor, cinematic lighting. No flicker, anatomy errors or object morphing."
    val animPrompt="SCENE ${p.scene} — ANIMATION + ASMR\n10-second mock scene; verify actual timing against approved storyboard. Slow cinematic camera, natural movement, stable identities.\n0–3s: Establish action and primary foley.\n3–7s: Continue action, secondary foley.\n7–10s: Settle into next scene.\nL1 Primary Foley: direct action.\nL2 Secondary Foley: subtle object details.\nL3 Environment: room tone.\nL4 Spatial: directional placement.\nNo unwanted dialogue or music. Preserve continuity."
    PromptCard("PROMPT A — IMAGE",imagePrompt,ctx)
    PromptCard("PROMPT B — ANIMATION + 4-LAYER ASMR",animPrompt,ctx)
    Button(onClick={p.step=13;onSave()},modifier=Modifier.fillMaxWidth()) { Text("REVIEW FINAL PACKAGE") }
    Text("Mock prompt generator: connect a secure AI backend in Milestone 2.",color=Color.LightGray)
}
@Composable private fun PromptCard(title:String,prompt:String,ctx:Context) {
    var copied by remember(prompt) { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth().padding(vertical=8.dp)) {
        Column(Modifier.padding(12.dp)) {
            Text(title,fontWeight=FontWeight.Bold)
            Spacer(Modifier.height(8.dp));Text(prompt)
            Button(onClick={
                val clipboard=ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText(title,prompt));copied=true
            },colors=ButtonDefaults.buttonColors(containerColor=if(copied) Purple else Color(0xFF37313F))) { Text(if(copied) "COPIED ✓" else "COPY PROMPT") }
        }
    }
}
